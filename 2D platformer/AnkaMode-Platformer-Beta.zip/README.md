# I see the light

Developed by Laura Isidro and Sofia Liles
This 2D platformer is a Videogame Development assigment


## Assets

https://maaot.itch.io/mossy-cavern

## Libraries Used

SDL

Pugi


## Languages Used

XML

C++
